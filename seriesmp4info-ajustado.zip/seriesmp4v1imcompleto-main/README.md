# Series MP4 Info

Projeto full stack com frontend React e backend FastAPI para listar filmes, exibir detalhes e página de apoio via PIX.

## O que foi ajustado

- fallback para imagens quebradas
- `netlify.toml` pronto para deploy do frontend
- `render.yaml` pronto para deploy do backend
- `_redirects` para React Router no Netlify
- `.env.example` no frontend e backend
- backend configurado para usar MongoDB e semear os filmes automaticamente
- fallback local para dados mockados quando o Mongo não estiver configurado
- footer com nome e e-mail configuráveis por variáveis de ambiente
- ano do footer automático

## Deploy

### 1) MongoDB Atlas
Crie um cluster, um usuário e copie a connection string.

### 2) Backend no Render
No serviço web do Render, use a pasta `backend` e adicione as variáveis do arquivo `backend/.env.example`.

Comando de start:

```bash
uvicorn server:app --host 0.0.0.0 --port $PORT
```

### 3) Frontend no Netlify
Use a pasta `frontend`.

Configuração esperada:

```bash
Build command: npm install && npm run build
Publish directory: build
```

Adicione as variáveis do arquivo `frontend/.env.example`.

## Variáveis importantes

### Backend

```env
MONGO_URL=...
DB_NAME=seriesmp4info
CORS_ORIGINS=https://seu-site.netlify.app,http://localhost:3000
PIX_KEY=11999999999
PIX_KEY_TYPE=telefone
PIX_BENEFICIARY_NAME=Series MP4 Info
CREATOR_NAME=Seu Nome
CREATOR_EMAIL=seuemail@exemplo.com
```

### Frontend

```env
REACT_APP_BACKEND_URL=https://seu-backend.onrender.com
REACT_APP_CREATOR_NAME=Seu Nome
REACT_APP_CREATOR_EMAIL=seuemail@exemplo.com
```

## Rodando localmente

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --reload
```

### Frontend

```bash
cd frontend
npm install
npm start
```
