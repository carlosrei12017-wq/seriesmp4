from fastapi import FastAPI, APIRouter, Query, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

app = FastAPI(title="Series MP4 Info API")
api_router = APIRouter(prefix="/api")

# MongoDB connection (optional fallback to mock data for local development)
MONGO_URL = os.getenv("MONGO_URL")
DB_NAME = os.getenv("DB_NAME", "seriesmp4info")
USE_MONGO = bool(MONGO_URL)
client = AsyncIOMotorClient(MONGO_URL) if USE_MONGO else None
db = client[DB_NAME] if client else None
MOVIES_COLLECTION = db["movies"] if db is not None else None

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Models
class Movie(BaseModel):
    id: int
    title: str
    original_title: str
    overview: str
    poster_path: str
    backdrop_path: str
    release_date: str
    vote_average: float
    vote_count: int
    genres: List[str]
    runtime: int
    original_language: str
    spoken_languages: List[str]
    has_dubbing: bool
    dubbing_languages: List[str]
    watch_providers: List[dict]

class Genre(BaseModel):
    id: int
    name: str

class DonationInfo(BaseModel):
    pix_key: str
    pix_key_type: str
    beneficiary_name: str
    message: str
    creator_name: str
    creator_email: str

# Mocked Movies Data
MOVIES_DATA = [
    {
        "id": 1,
        "title": "Oppenheimer",
        "original_title": "Oppenheimer",
        "overview": "A história do físico J. Robert Oppenheimer e seu papel no desenvolvimento da bomba atômica durante a Segunda Guerra Mundial. O filme explora os dilemas morais e as consequências devastadoras de suas descobertas científicas.",
        "poster_path": "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/fm6KqXpk3M2HVveHwCrBSSBaO0V.jpg",
        "release_date": "2023-07-21",
        "vote_average": 8.1,
        "vote_count": 8542,
        "genres": ["Drama", "História", "Suspense"],
        "runtime": 180,
        "original_language": "en",
        "spoken_languages": ["Inglês", "Alemão", "Holandês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês"],
        "watch_providers": [
            {"name": "Amazon Prime Video", "logo": "https://image.tmdb.org/t/p/original/emthp39XA2YScoYL1p0sdbAH2WA.jpg"},
            {"name": "Apple TV", "logo": "https://image.tmdb.org/t/p/original/6uhKBfmtzFqOcLousHwZuzcrScK.jpg"}
        ]
    },
    {
        "id": 2,
        "title": "Barbie",
        "original_title": "Barbie",
        "overview": "Barbie e Ken estão se divertindo no mundo colorido e aparentemente perfeito da Barbieland. No entanto, quando eles têm a chance de ir ao mundo real, logo descobrem as alegrias e os perigos de viver entre os humanos.",
        "poster_path": "https://image.tmdb.org/t/p/w500/iuFNMS8U5cb6xfzi51Dbkovj7vM.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/nHf61UzkfFno5X1ofIhugCPus2R.jpg",
        "release_date": "2023-07-21",
        "vote_average": 7.0,
        "vote_count": 7823,
        "genres": ["Comédia", "Aventura", "Fantasia"],
        "runtime": 114,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês", "Alemão"],
        "watch_providers": [
            {"name": "Max", "logo": "https://image.tmdb.org/t/p/original/6Q3ZYUNA9Hsgj6iWnVsw2gR5V6z.jpg"},
            {"name": "Amazon Prime Video", "logo": "https://image.tmdb.org/t/p/original/emthp39XA2YScoYL1p0sdbAH2WA.jpg"}
        ]
    },
    {
        "id": 3,
        "title": "Duna: Parte 2",
        "original_title": "Dune: Part Two",
        "overview": "Paul Atreides se une a Chani e aos Fremen enquanto busca vingança contra os conspiradores que destruíram sua família. Enfrentando uma escolha entre o amor de sua vida e o destino do universo, ele deve evitar um futuro terrível.",
        "poster_path": "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/xOMo8BRK7PfcJv9JCnx7s5hj0PX.jpg",
        "release_date": "2024-02-28",
        "vote_average": 8.3,
        "vote_count": 5234,
        "genres": ["Ficção Científica", "Aventura", "Drama"],
        "runtime": 166,
        "original_language": "en",
        "spoken_languages": ["Inglês", "Árabe"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol"],
        "watch_providers": [
            {"name": "Max", "logo": "https://image.tmdb.org/t/p/original/6Q3ZYUNA9Hsgj6iUwVsw2gR5V6z.jpg"},
            {"name": "Apple TV", "logo": "https://image.tmdb.org/t/p/original/6uhKBfmtzFqOcLousHwZuzcrScK.jpg"}
        ]
    },
    {
        "id": 4,
        "title": "Pobres Criaturas",
        "original_title": "Poor Things",
        "overview": "A incrível história de Bella Baxter, uma jovem trazida de volta à vida pelo brilhante e pouco ortodoxo cientista Dr. Godwin Baxter. Sob a proteção de Baxter, Bella anseia por aprender sobre o mundo.",
        "poster_path": "https://image.tmdb.org/t/p/w500/kCGlIMHnOm8JPXq3rXM6c5wMxcT.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/bQS43HSLZzMjZkcHJz4fGc7fNdz.jpg",
        "release_date": "2023-12-08",
        "vote_average": 7.9,
        "vote_count": 4521,
        "genres": ["Ficção Científica", "Romance", "Comédia"],
        "runtime": 141,
        "original_language": "en",
        "spoken_languages": ["Inglês", "Francês", "Português"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol"],
        "watch_providers": [
            {"name": "Star+", "logo": "https://image.tmdb.org/t/p/original/gJ3yVMWouaVj6iHd59TISJ1TlM5.jpg"},
            {"name": "Amazon Prime Video", "logo": "https://image.tmdb.org/t/p/original/emthp39XA2YScoYL1p0sdbAH2WA.jpg"}
        ]
    },
    {
        "id": 5,
        "title": "Ainda Estou Aqui",
        "original_title": "Ainda Estou Aqui",
        "overview": "Brasil, início dos anos 1970. Eunice Paiva, mãe de cinco filhos, é casada com Rubens Paiva, ex-deputado cassado pela ditadura. Quando o marido é levado por militares, ela começa uma busca incansável por respostas.",
        "poster_path": "https://image.tmdb.org/t/p/w500/9kN3ycCXhZ6VVbALQiZQr9EBdC8.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/417tYZ4XUyJrtyZXj7HpvWf1E8f.jpg",
        "release_date": "2024-09-19",
        "vote_average": 8.5,
        "vote_count": 2341,
        "genres": ["Drama", "História"],
        "runtime": 135,
        "original_language": "pt",
        "spoken_languages": ["Português"],
        "has_dubbing": False,
        "dubbing_languages": [],
        "watch_providers": [
            {"name": "Globoplay", "logo": "https://image.tmdb.org/t/p/original/moTaQj05SqidnVFOzJujHhWpF3A.jpg"}
        ]
    },
    {
        "id": 6,
        "title": "Assassino Profissional",
        "original_title": "The Killer",
        "overview": "Após um erro fatal em uma missão, um assassino profissional metódico trava uma guerra contra seus empregadores e ele mesmo, viajando pelo mundo enquanto reflete sobre sua carreira.",
        "poster_path": "https://image.tmdb.org/t/p/w500/e7Jvsry47JJQruuezjU2X1Z6J77.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/mDeUmPe4MF35WWlAqj4QFX5UauJ.jpg",
        "release_date": "2023-10-27",
        "vote_average": 6.8,
        "vote_count": 3456,
        "genres": ["Ação", "Suspense", "Crime"],
        "runtime": 118,
        "original_language": "en",
        "spoken_languages": ["Inglês", "Francês", "Espanhol"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol"],
        "watch_providers": [
            {"name": "Netflix", "logo": "https://image.tmdb.org/t/p/original/t2yyOv40HZeVlLjYsCsPHnWLk4W.jpg"}
        ]
    },
    {
        "id": 7,
        "title": "Napoleão",
        "original_title": "Napoleon",
        "overview": "Uma épica que detalha as origens de Napoleão Bonaparte e sua rápida e implacável ascensão ao poder. O filme cobre as batalhas icônicas, a ambição sem limites e o relacionamento com Josefina.",
        "poster_path": "https://image.tmdb.org/t/p/w500/jE5o7y9K6pZtWNNMEw3IdpHuncR.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/dSBDj6PvGNXQRPpXMrvlvW5kP4q.jpg",
        "release_date": "2023-11-22",
        "vote_average": 6.5,
        "vote_count": 4123,
        "genres": ["Drama", "História", "Guerra"],
        "runtime": 158,
        "original_language": "en",
        "spoken_languages": ["Inglês", "Francês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês"],
        "watch_providers": [
            {"name": "Apple TV+", "logo": "https://image.tmdb.org/t/p/original/6uhKBfmtzFqOcLousHwZuzcrScK.jpg"},
            {"name": "Amazon Prime Video", "logo": "https://image.tmdb.org/t/p/original/emthp39XA2YScoYL1p0sdbAH2WA.jpg"}
        ]
    },
    {
        "id": 8,
        "title": "Wonka",
        "original_title": "Wonka",
        "overview": "A história de como o maior inventor, mágico e chocolateiro do mundo se tornou o amado Willy Wonka que conhecemos hoje. Baseado no personagem icônico de Roald Dahl.",
        "poster_path": "https://image.tmdb.org/t/p/w500/qhb1qOilapbapxWQn9jtRCMwXJF.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/yOm993lsJyPmBodlYjgpPwBjXP9.jpg",
        "release_date": "2023-12-06",
        "vote_average": 7.2,
        "vote_count": 3876,
        "genres": ["Comédia", "Família", "Fantasia"],
        "runtime": 116,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês", "Alemão"],
        "watch_providers": [
            {"name": "Max", "logo": "https://image.tmdb.org/t/p/original/6Q3ZYUNA9Hsgj6iUwVsw2gR5V6z.jpg"}
        ]
    },
    {
        "id": 9,
        "title": "Divertida Mente 2",
        "original_title": "Inside Out 2",
        "overview": "Riley está entrando na adolescência e o Quartel-General está passando por uma reforma para abrir espaço para algo totalmente inesperado: novas emoções! Alegria, Tristeza, Raiva, Medo e Nojinho dão as boas-vindas à Ansiedade.",
        "poster_path": "https://image.tmdb.org/t/p/w500/vpnVM9B6NMmQpWeZvzLvDESb2QY.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/xg27NrXi7VXCGUr7MG75UqLl6Vg.jpg",
        "release_date": "2024-06-11",
        "vote_average": 7.6,
        "vote_count": 6234,
        "genres": ["Animação", "Família", "Comédia"],
        "runtime": 97,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês", "Italiano", "Alemão"],
        "watch_providers": [
            {"name": "Disney+", "logo": "https://image.tmdb.org/t/p/original/7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg"}
        ]
    },
    {
        "id": 10,
        "title": "Gladiador 2",
        "original_title": "Gladiator II",
        "overview": "Lucius, o filho de Lucilla e sobrinho de Commodus, testemunhou a morte de Maximus nas mãos de seu tio. Agora adulto, Lucius é forçado a entrar no Coliseu e deve buscar força no legado de Maximus.",
        "poster_path": "https://image.tmdb.org/t/p/w500/2cxhvwyEwRlysAmRH4iodkvo0z5.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/euYIwmwkmz95mnXvufEmbL6ovhZ.jpg",
        "release_date": "2024-11-13",
        "vote_average": 6.9,
        "vote_count": 2145,
        "genres": ["Ação", "Aventura", "Drama"],
        "runtime": 148,
        "original_language": "en",
        "spoken_languages": ["Inglês", "Latim"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol"],
        "watch_providers": [
            {"name": "Paramount+", "logo": "https://image.tmdb.org/t/p/original/xbhHHa1YgtpwhC8lb1NQ3ACVcLd.jpg"}
        ]
    },
    {
        "id": 11,
        "title": "O Auto da Compadecida 2",
        "original_title": "O Auto da Compadecida 2",
        "overview": "Chicó e João Grilo se reencontram depois de muitos anos. João agora é um homem rico e famoso, mas seus velhos hábitos de enganar as pessoas não mudaram. Juntos, eles enfrentam novas aventuras no sertão nordestino.",
        "poster_path": "https://image.tmdb.org/t/p/w500/a8uWqh3zH9vMSdexEjSpIjgpMuX.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/7p8x0bjcqwDOdJj3RhYF8Ygvfwp.jpg",
        "release_date": "2024-12-25",
        "vote_average": 8.2,
        "vote_count": 1876,
        "genres": ["Comédia", "Drama"],
        "runtime": 120,
        "original_language": "pt",
        "spoken_languages": ["Português"],
        "has_dubbing": False,
        "dubbing_languages": [],
        "watch_providers": [
            {"name": "Globoplay", "logo": "https://image.tmdb.org/t/p/original/moTaQj05SqidnVFOzJujHhWpF3A.jpg"},
            {"name": "Nos Cinemas", "logo": ""}
        ]
    },
    {
        "id": 12,
        "title": "Coringa: Delírio a Dois",
        "original_title": "Joker: Folie à Deux",
        "overview": "Arthur Fleck está internado em Arkham à espera do julgamento por seus crimes como Coringa. Enquanto luta com sua dupla identidade, Arthur não apenas encontra o amor verdadeiro, mas também a música que sempre esteve dentro dele.",
        "poster_path": "https://image.tmdb.org/t/p/w500/if8QiqCI7WAGImKcJCfzp6VTyKA.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/uGmYqxh8flqkudioyFtD7IJSHc9.jpg",
        "release_date": "2024-10-01",
        "vote_average": 5.7,
        "vote_count": 3421,
        "genres": ["Drama", "Crime", "Musical"],
        "runtime": 138,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol"],
        "watch_providers": [
            {"name": "Max", "logo": "https://image.tmdb.org/t/p/original/6Q3ZYUNA9Hsgj6iUwVsw2gR5V6z.jpg"}
        ]
    },
    {
        "id": 13,
        "title": "Deadpool & Wolverine",
        "original_title": "Deadpool & Wolverine",
        "overview": "Deadpool enfrenta uma crise existencial quando descobre que seu universo está à beira da destruição. Para salvá-lo, ele precisa convencer um relutante Wolverine a se juntar a ele em uma missão que mudará a ambos para sempre.",
        "poster_path": "https://image.tmdb.org/t/p/w500/8cdWjvZQUExUUTzyp4t6EDMubfO.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/yDHYTfA3R0jFYba16jBB1ef8oIt.jpg",
        "release_date": "2024-07-26",
        "vote_average": 7.8,
        "vote_count": 5678,
        "genres": ["Ação", "Comédia", "Ficção Científica"],
        "runtime": 128,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês"],
        "watch_providers": [
            {"name": "Disney+", "logo": "https://image.tmdb.org/t/p/original/7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg"}
        ]
    },
    {
        "id": 14,
        "title": "Terrifier 3",
        "original_title": "Terrifier 3",
        "overview": "Art, o Palhaço, está de volta para causar mais caos e terror na noite de Natal, mirando em uma adolescente sobrevivente e sua família enquanto espalha sua marca de violência extrema.",
        "poster_path": "https://image.tmdb.org/t/p/w500/63xYQj1BwRFielxsBDXvHIJyXVm.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/18TSJF1WLA4CkymvVUcKDBwUJ9F.jpg",
        "release_date": "2024-10-11",
        "vote_average": 7.0,
        "vote_count": 1234,
        "genres": ["Terror", "Suspense"],
        "runtime": 125,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português"],
        "watch_providers": [
            {"name": "Amazon Prime Video", "logo": "https://image.tmdb.org/t/p/original/emthp39XA2YScoYL1p0sdbAH2WA.jpg"}
        ]
    },
    {
        "id": 15,
        "title": "Moana 2",
        "original_title": "Moana 2",
        "overview": "Moana recebe um chamado inesperado de seus ancestrais e deve viajar para os mares distantes da Oceania, entrando em águas perigosas e há muito esquecidas para uma aventura diferente de tudo que já viveu.",
        "poster_path": "https://image.tmdb.org/t/p/w500/yh64qw9mgXBvlaWDi7Q9tpUBAvH.jpg",
        "backdrop_path": "https://image.tmdb.org/t/p/original/tElnmtQ6yz1PjN1kePNl8yMSb59.jpg",
        "release_date": "2024-11-27",
        "vote_average": 7.2,
        "vote_count": 2890,
        "genres": ["Animação", "Aventura", "Família"],
        "runtime": 100,
        "original_language": "en",
        "spoken_languages": ["Inglês"],
        "has_dubbing": True,
        "dubbing_languages": ["Português", "Espanhol", "Francês"],
        "watch_providers": [
            {"name": "Disney+", "logo": "https://image.tmdb.org/t/p/original/7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg"}
        ]
    }
]

GENRES = [
    {"id": 1, "name": "Ação"},
    {"id": 2, "name": "Aventura"},
    {"id": 3, "name": "Animação"},
    {"id": 4, "name": "Comédia"},
    {"id": 5, "name": "Crime"},
    {"id": 6, "name": "Drama"},
    {"id": 7, "name": "Família"},
    {"id": 8, "name": "Fantasia"},
    {"id": 9, "name": "Ficção Científica"},
    {"id": 10, "name": "Guerra"},
    {"id": 11, "name": "História"},
    {"id": 12, "name": "Musical"},
    {"id": 13, "name": "Romance"},
    {"id": 14, "name": "Suspense"},
    {"id": 15, "name": "Terror"}
]



DONATION_INFO = {
    "pix_key": os.getenv("PIX_KEY", "19996471138"),
    "pix_key_type": os.getenv("PIX_KEY_TYPE", "telefone"),
    "beneficiary_name": os.getenv("PIX_BENEFICIARY_NAME", "Series MP4 Info"),
    "message": os.getenv("DONATION_MESSAGE", "Ajude a manter o Series MP4 Info no ar! Sua doação nos ajuda a continuar trazendo informações sobre filmes e séries para você."),
    "creator_name": os.getenv("CREATOR_NAME", "Seu Nome"),
    "creator_email": os.getenv("CREATOR_EMAIL", "seuemail@exemplo.com")
}

async def ensure_seed_data():
    if MOVIES_COLLECTION is None:
        logger.info("MongoDB não configurado. API usando dados mockados locais.")
        return

    count = await MOVIES_COLLECTION.count_documents({})
    if count == 0:
        await MOVIES_COLLECTION.insert_many(MOVIES_DATA)
        logger.info("Banco Mongo inicializado com %s filmes.", len(MOVIES_DATA))


async def get_movies_source() -> List[dict]:
    if MOVIES_COLLECTION is None:
        return MOVIES_DATA.copy()

    movies = await MOVIES_COLLECTION.find({}, {"_id": 0}).to_list(length=1000)
    return movies or MOVIES_DATA.copy()


def sanitize_movie(movie: dict) -> dict:
    movie = dict(movie)
    movie.pop("_id", None)
    if not movie.get("poster_path"):
        movie["poster_path"] = "/placeholder-poster.svg"
    if not movie.get("backdrop_path"):
        movie["backdrop_path"] = movie["poster_path"]
    return movie


# Routes
@api_router.get("/")
async def root():
    return {"message": "Series MP4 Info API"}

@api_router.get("/movies", response_model=List[Movie])
async def get_movies(
    search: Optional[str] = Query(None, description="Search by title"),
    genre: Optional[str] = Query(None, description="Filter by genre"),
    year: Optional[int] = Query(None, description="Filter by year"),
    page: int = Query(1, ge=1),
    limit: int = Query(12, ge=1, le=50)
):
    filtered = [sanitize_movie(movie) for movie in await get_movies_source()]
    
    if search:
        search_lower = search.lower()
        filtered = [m for m in filtered if search_lower in m["title"].lower() or search_lower in m["original_title"].lower()]
    
    if genre:
        filtered = [m for m in filtered if genre in m["genres"]]
    
    if year:
        filtered = [m for m in filtered if m["release_date"].startswith(str(year))]
    
    start = (page - 1) * limit
    end = start + limit
    return filtered[start:end]

@api_router.get("/movies/featured", response_model=List[Movie])
async def get_featured_movies():
    movies = [sanitize_movie(movie) for movie in await get_movies_source()]
    sorted_movies = sorted(movies, key=lambda x: x["vote_average"], reverse=True)
    return sorted_movies[:5]

@api_router.get("/movies/{movie_id}", response_model=Movie)
async def get_movie(movie_id: int):
    movies = await get_movies_source()
    for movie in movies:
        if movie["id"] == movie_id:
            return sanitize_movie(movie)
    raise HTTPException(status_code=404, detail="Movie not found")

@api_router.get("/genres", response_model=List[Genre])
async def get_genres():
    return GENRES

@api_router.get("/donation", response_model=DonationInfo)
async def get_donation_info():
    return DONATION_INFO

@api_router.get("/years")
async def get_available_years():
    years = set()
    for movie in await get_movies_source():
        year = movie["release_date"][:4]
        years.add(int(year))
    return sorted(list(years), reverse=True)

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    await ensure_seed_data()


@app.on_event("shutdown")
async def shutdown_db_client():
    if client is not None:
        client.close()
