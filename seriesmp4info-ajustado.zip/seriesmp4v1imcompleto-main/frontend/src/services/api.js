import axios from 'axios';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || 'http://localhost:8000').replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

export const api = {
  getMovies: async (params = {}) => {
    const { search, genre, year, page = 1, limit = 12 } = params;
    const queryParams = new URLSearchParams();
    if (search) queryParams.append('search', search);
    if (genre) queryParams.append('genre', genre);
    if (year) queryParams.append('year', year);
    queryParams.append('page', page);
    queryParams.append('limit', limit);
    
    const response = await axios.get(`${API}/movies?${queryParams.toString()}`);
    return response.data;
  },

  getFeaturedMovies: async () => {
    const response = await axios.get(`${API}/movies/featured`);
    return response.data;
  },

  getMovie: async (id) => {
    const response = await axios.get(`${API}/movies/${id}`);
    return response.data;
  },

  getGenres: async () => {
    const response = await axios.get(`${API}/genres`);
    return response.data;
  },

  getYears: async () => {
    const response = await axios.get(`${API}/years`);
    return response.data;
  },

  getDonationInfo: async () => {
    const response = await axios.get(`${API}/donation`);
    return response.data;
  }
};
