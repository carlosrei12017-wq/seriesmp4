import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { HeroSection } from '../components/HeroSection';
import { SearchFilters } from '../components/SearchFilters';
import { MovieGrid } from '../components/MovieGrid';

export const HomePage = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    genre: '',
    year: null
  });

  useEffect(() => {
    const fetchMovies = async () => {
      setLoading(true);
      try {
        const data = await api.getMovies(filters);
        setMovies(data);
      } catch (error) {
        console.error('Error fetching movies:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchMovies();
  }, [filters]);

  return (
    <div data-testid="home-page">
      <HeroSection />
      
      <main className="container mx-auto px-4 md:px-6 lg:px-8 py-12">
        <SearchFilters filters={filters} onFilterChange={setFilters} />
        
        <section>
          <h2 className="text-2xl md:text-3xl font-bold mb-6 font-heading">
            {filters.search || filters.genre || filters.year ? 'Resultados' : 'Todos os Filmes'}
          </h2>
          <MovieGrid movies={movies} loading={loading} />
        </section>
      </main>
    </div>
  );
};
