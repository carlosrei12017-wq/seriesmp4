import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  ArrowLeft, 
  Star, 
  Clock, 
  Calendar,
  Globe,
  Mic2,
  Languages,
  Play,
  ExternalLink,
  Loader2
} from 'lucide-react';

export const MovieDetailPage = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const data = await api.getMovie(id);
        setMovie(data);
      } catch (error) {
        console.error('Error fetching movie:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchMovie();
  }, [id]);

  const getRatingColor = (rating) => {
    if (rating >= 7.5) return 'text-emerald-400';
    if (rating >= 6) return 'text-amber-400';
    return 'text-red-400';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="movie-detail-loading">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center" data-testid="movie-not-found">
        <h1 className="text-2xl font-bold mb-4">Filme não encontrado</h1>
        <Link to="/">
          <Button>Voltar para Início</Button>
        </Link>
      </div>
    );
  }

  return (
    <div data-testid="movie-detail-page">
      {/* Backdrop */}
      <div className="relative h-[50vh] md:h-[60vh] w-full overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${movie.backdrop_path || movie.poster_path || '/placeholder-poster.svg'})` }}
        >
          <div className="absolute inset-0 bg-black/70" />
          <div className="absolute bottom-0 left-0 right-0 h-2/3 hero-gradient" />
        </div>

        {/* Back Button */}
        <div className="absolute top-24 left-4 md:left-8 z-10">
          <Link to="/">
            <Button variant="ghost" className="glass rounded-full" data-testid="back-button">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Voltar
            </Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <main className="container mx-auto px-4 md:px-6 lg:px-8 -mt-40 md:-mt-60 relative z-10 pb-20">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0 mx-auto md:mx-0">
            <div className="relative w-64 md:w-80 aspect-[2/3] rounded-xl overflow-hidden shadow-2xl glow-card">
              <img 
                src={movie.poster_path || '/placeholder-poster.svg'} 
                alt={movie.title}
                onError={(e) => { e.currentTarget.src = '/placeholder-poster.svg'; }}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 text-center md:text-left">
            {/* Genres */}
            <div className="flex flex-wrap justify-center md:justify-start gap-2 mb-4">
              {movie.genres.map((genre, i) => (
                <Badge key={i} className="bg-primary/20 text-primary border-primary/30 text-xs uppercase tracking-wider">
                  {genre}
                </Badge>
              ))}
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-5xl font-bold mb-2 font-heading">{movie.title}</h1>
            {movie.title !== movie.original_title && (
              <p className="text-muted-foreground mb-4 text-lg">{movie.original_title}</p>
            )}

            {/* Stats */}
            <div className="flex flex-wrap justify-center md:justify-start items-center gap-4 md:gap-6 mb-6 text-sm">
              <span className={`flex items-center gap-1 font-bold text-lg ${getRatingColor(movie.vote_average)}`}>
                <Star className="w-5 h-5" fill="currentColor" />
                {movie.vote_average.toFixed(1)}
                <span className="text-muted-foreground font-normal text-xs">({movie.vote_count} votos)</span>
              </span>
              <span className="flex items-center gap-1 text-muted-foreground">
                <Calendar className="w-4 h-4" />
                {movie.release_date}
              </span>
              <span className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-4 h-4" />
                {Math.floor(movie.runtime / 60)}h {movie.runtime % 60}min
              </span>
              <span className="flex items-center gap-1 text-muted-foreground">
                <Globe className="w-4 h-4" />
                {movie.original_language.toUpperCase()}
              </span>
            </div>

            {/* Synopsis */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-3">Sinopse</h2>
              <p className="text-muted-foreground leading-relaxed">{movie.overview}</p>
            </div>

            {/* Languages */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="glass rounded-xl p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Languages className="w-5 h-5 text-primary" />
                  Idiomas Disponíveis
                </h3>
                <div className="flex flex-wrap gap-2">
                  {movie.spoken_languages.map((lang, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">
                      {lang}
                    </Badge>
                  ))}
                </div>
              </div>

              {movie.has_dubbing && (
                <div className="glass rounded-xl p-4">
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <Mic2 className="w-5 h-5 text-cyan-400" />
                    Dublagem Disponível
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {movie.dubbing_languages.map((lang, i) => (
                      <Badge key={i} className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs">
                        {lang}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Watch Providers */}
            <div className="glass rounded-xl p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Play className="w-5 h-5 text-primary" />
                Onde Assistir
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {movie.watch_providers.map((provider, i) => (
                  <div 
                    key={i}
                    className="flex items-center gap-3 p-3 rounded-lg bg-background/50 hover:bg-background/80 transition-colors cursor-pointer"
                    data-testid={`provider-${i}`}
                  >
                    {provider.logo ? (
                      <img 
                        src={provider.logo || '/placeholder-poster.svg'} 
                        alt={provider.name}
                        onError={(e) => { e.currentTarget.src = '/placeholder-poster.svg'; }}
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        <ExternalLink className="w-5 h-5 text-primary" />
                      </div>
                    )}
                    <span className="text-sm font-medium">{provider.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
