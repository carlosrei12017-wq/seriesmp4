import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  Heart, 
  Copy, 
  Check, 
  QrCode,
  Smartphone,
  Mail,
  User,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';

export const DonationPage = () => {
  const [donationInfo, setDonationInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchDonationInfo = async () => {
      try {
        const data = await api.getDonationInfo();
        setDonationInfo(data);
      } catch (error) {
        console.error('Error fetching donation info:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchDonationInfo();
  }, []);

  const copyPixKey = async () => {
    if (!donationInfo) return;
    
    try {
      await navigator.clipboard.writeText(donationInfo.pix_key);
      setCopied(true);
      toast.success('Chave PIX copiada!');
      setTimeout(() => setCopied(false), 3000);
    } catch (error) {
      toast.error('Erro ao copiar');
    }
  };

  // Generate PIX QR Code URL using a free API
  const generatePixQRCode = () => {
    if (!donationInfo) return '';
    // Using a QR code generator API
    const pixCode = donationInfo.pix_key;
    return `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(pixCode)}&bgcolor=0f0f10&color=FFFFFF`;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20" data-testid="donation-loading">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!donationInfo) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20" data-testid="donation-error">
        <p className="text-muted-foreground">Erro ao carregar informações de doação</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-12" data-testid="donation-page">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12 animate-slide-up">
          <Badge className="bg-secondary/20 text-secondary border-secondary/30 mb-4">
            <Heart className="w-3 h-3 mr-1" fill="currentColor" />
            Apoie o Projeto
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 font-heading">
            Ajude o <span className="neon-text">Series MP4 Info</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            {donationInfo.message}
          </p>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
          {/* QR Code Card */}
          <Card className="glass overflow-hidden" data-testid="qr-code-card">
            <CardHeader className="text-center pb-4">
              <CardTitle className="flex items-center justify-center gap-2">
                <QrCode className="w-5 h-5 text-primary" />
                QR Code PIX
              </CardTitle>
              <CardDescription>
                Escaneie o código com seu app de banco
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <div className="bg-white p-4 rounded-2xl mb-6 glow-card">
                <img 
                  src={generatePixQRCode()}
                  alt="QR Code PIX"
                  className="w-64 h-64 object-contain"
                  data-testid="pix-qr-code"
                />
              </div>
              <p className="text-sm text-muted-foreground text-center">
                Abra o app do seu banco, escolha pagar com PIX e escaneie o QR Code acima
              </p>
            </CardContent>
          </Card>

          {/* PIX Info Card */}
          <Card className="glass" data-testid="pix-info-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-cyan-400" />
                Chave PIX
              </CardTitle>
              <CardDescription>
                Ou copie a chave manualmente
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* PIX Key */}
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Chave ({donationInfo.pix_key_type})</label>
                <div className="flex gap-2">
                  <div className="flex-1 glass rounded-lg px-4 py-3 font-mono text-lg">
                    {donationInfo.pix_key}
                  </div>
                  <Button 
                    onClick={copyPixKey}
                    className={`rounded-lg transition-all ${copied ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-primary hover:bg-primary/80'}`}
                    data-testid="copy-pix-button"
                  >
                    {copied ? (
                      <Check className="w-5 h-5" />
                    ) : (
                      <Copy className="w-5 h-5" />
                    )}
                  </Button>
                </div>
              </div>

              {/* Beneficiary */}
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground flex items-center gap-1">
                  <User className="w-4 h-4" />
                  Beneficiário
                </label>
                <div className="glass rounded-lg px-4 py-3">
                  {donationInfo.beneficiary_name}
                </div>
              </div>

              {/* Instructions */}
              <div className="glass rounded-xl p-4 bg-primary/5">
                <h4 className="font-semibold mb-2 text-sm">Como doar:</h4>
                <ol className="text-sm text-muted-foreground space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
                    Abra o app do seu banco
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
                    Escolha pagar com PIX
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">3</span>
                    Escaneie o QR Code ou cole a chave
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">4</span>
                    Insira o valor e confirme
                  </li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Creator Info */}
        <div className="max-w-4xl mx-auto mt-12">
          <Card className="glass" data-testid="creator-card">
            <CardContent className="flex flex-col md:flex-row items-center justify-between gap-4 py-6">
              <div className="text-center md:text-left">
                <p className="text-sm text-muted-foreground mb-1">Criado por</p>
                <p className="font-semibold text-lg">{donationInfo.creator_name}</p>
              </div>
              <a 
                href={`mailto:${donationInfo.creator_email}`}
                className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
              >
                <Mail className="w-4 h-4" />
                {donationInfo.creator_email}
              </a>
            </CardContent>
          </Card>
        </div>

        {/* Thank you message */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground">
            Obrigado por apoiar o <span className="text-primary font-semibold">Series MP4 Info</span>!
          </p>
        </div>
      </div>
    </div>
  );
};
