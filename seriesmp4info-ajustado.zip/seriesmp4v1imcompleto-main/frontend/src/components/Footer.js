import { Film, Heart, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

const creatorName = process.env.REACT_APP_CREATOR_NAME || 'Seu Nome';
const creatorEmail = process.env.REACT_APP_CREATOR_EMAIL || 'seuemail@exemplo.com';

export const Footer = () => {
  return (
    <footer className="border-t border-border/20 bg-surface/50 backdrop-blur-sm" data-testid="footer">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Film className="w-6 h-6 text-primary" />
              <span className="text-lg font-bold font-heading neon-text">Series MP4 Info</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Seu guia completo para descobrir onde assistir seus filmes e séries favoritos.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/donation" className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
                  <Heart className="w-3 h-3" />
                  Apoiar o projeto
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Criador</h4>
            <p className="text-sm text-muted-foreground mb-2">{creatorName}</p>
            <a 
              href={`mailto:${creatorEmail}`} 
              className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
            >
              <Mail className="w-3 h-3" />
              {creatorEmail}
            </a>
          </div>
        </div>

        <div className="border-t border-border/20 mt-8 pt-8 text-center">
          <p className="text-xs text-muted-foreground">
            {new Date().getFullYear()} Series MP4 Info. Todos os dados de filmes são apenas informativos.
          </p>
        </div>
      </div>
    </footer>
  );
};
