import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Search, X, Filter, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

export const SearchFilters = ({ onFilterChange, filters }) => {
  const [genres, setGenres] = useState([]);
  const [years, setYears] = useState([]);
  const [searchValue, setSearchValue] = useState(filters.search || '');
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  useEffect(() => {
    const fetchFilters = async () => {
      try {
        const [genresData, yearsData] = await Promise.all([
          api.getGenres(),
          api.getYears()
        ]);
        setGenres(genresData);
        setYears(yearsData);
      } catch (error) {
        console.error('Error fetching filters:', error);
      }
    };
    fetchFilters();
  }, []);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    onFilterChange({ ...filters, search: searchValue });
  };

  const handleGenreSelect = (genreName) => {
    const newGenre = filters.genre === genreName ? '' : genreName;
    onFilterChange({ ...filters, genre: newGenre });
  };

  const handleYearSelect = (year) => {
    const newYear = filters.year === year ? null : year;
    onFilterChange({ ...filters, year: newYear });
  };

  const clearFilters = () => {
    setSearchValue('');
    onFilterChange({ search: '', genre: '', year: null });
  };

  const hasActiveFilters = filters.search || filters.genre || filters.year;

  return (
    <div className="glass rounded-2xl p-4 md:p-6 mb-8" data-testid="search-filters">
      {/* Search Bar */}
      <form onSubmit={handleSearchSubmit} className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Buscar filmes..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-12 h-12 rounded-full bg-background/50 border-border/30 focus:border-primary/50"
            data-testid="search-input"
          />
        </div>
        <Button 
          type="submit" 
          className="h-12 px-6 rounded-full bg-primary hover:bg-primary/80 glow-button"
          data-testid="search-button"
        >
          <Search className="w-5 h-5" />
        </Button>
        <Button 
          type="button"
          variant="outline"
          className="h-12 px-4 rounded-full md:hidden border-border/30"
          onClick={() => setShowMobileFilters(!showMobileFilters)}
          data-testid="mobile-filter-toggle"
        >
          <Filter className="w-5 h-5" />
        </Button>
      </form>

      {/* Desktop Filters */}
      <div className={`${showMobileFilters ? 'flex' : 'hidden md:flex'} flex-col md:flex-row gap-4 items-start md:items-center`}>
        {/* Genre Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="outline" 
              className="h-10 rounded-full border-border/30 hover:border-primary/50"
              data-testid="genre-dropdown"
            >
              {filters.genre || 'Gênero'}
              <ChevronDown className="w-4 h-4 ml-2" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="glass max-h-64 overflow-y-auto">
            {genres.map((genre) => (
              <DropdownMenuItem 
                key={genre.id}
                onClick={() => handleGenreSelect(genre.name)}
                className={filters.genre === genre.name ? 'bg-primary/20' : ''}
                data-testid={`genre-option-${genre.id}`}
              >
                {genre.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Year Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="outline" 
              className="h-10 rounded-full border-border/30 hover:border-primary/50"
              data-testid="year-dropdown"
            >
              {filters.year || 'Ano'}
              <ChevronDown className="w-4 h-4 ml-2" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="glass max-h-64 overflow-y-auto">
            {years.map((year) => (
              <DropdownMenuItem 
                key={year}
                onClick={() => handleYearSelect(year)}
                className={filters.year === year ? 'bg-primary/20' : ''}
                data-testid={`year-option-${year}`}
              >
                {year}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Active Filters */}
        {hasActiveFilters && (
          <div className="flex flex-wrap gap-2 items-center">
            {filters.search && (
              <Badge className="bg-primary/20 text-primary border-primary/30 pl-3 pr-2 py-1">
                "{filters.search}"
                <button onClick={() => { setSearchValue(''); onFilterChange({ ...filters, search: '' }); }} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            )}
            {filters.genre && (
              <Badge className="bg-secondary/20 text-secondary border-secondary/30 pl-3 pr-2 py-1">
                {filters.genre}
                <button onClick={() => onFilterChange({ ...filters, genre: '' })} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            )}
            {filters.year && (
              <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 pl-3 pr-2 py-1">
                {filters.year}
                <button onClick={() => onFilterChange({ ...filters, year: null })} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            )}
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearFilters}
              className="text-muted-foreground hover:text-foreground"
              data-testid="clear-filters"
            >
              Limpar filtros
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
