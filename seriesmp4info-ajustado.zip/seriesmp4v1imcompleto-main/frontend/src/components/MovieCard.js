import { Link } from 'react-router-dom';
import { Star, Play, Mic2, Globe } from 'lucide-react';
import { Badge } from './ui/badge';

export const MovieCard = ({ movie, index = 0 }) => {
  const getRatingColor = (rating) => {
    if (rating >= 7.5) return 'text-emerald-400';
    if (rating >= 6) return 'text-amber-400';
    return 'text-red-400';
  };

  return (
    <Link 
      to={`/movie/${movie.id}`}
      className="movie-card group relative overflow-hidden rounded-xl block animate-slide-up opacity-0"
      style={{ animationDelay: `${index * 0.05}s`, animationFillMode: 'forwards' }}
      data-testid={`movie-card-${movie.id}`}
    >
      <div className="aspect-[2/3] relative">
        <img 
          src={movie.poster_path || '/placeholder-poster.svg'} 
          alt={movie.title}
          onError={(e) => { e.currentTarget.src = '/placeholder-poster.svg'; }}
          className="w-full h-full object-cover rounded-xl"
          loading="lazy"
        />
        
        {/* Overlay */}
        <div className="movie-overlay absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent rounded-xl flex flex-col justify-end p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="flex items-center gap-2 mb-2">
            {movie.has_dubbing && (
              <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs backdrop-blur-sm">
                <Mic2 className="w-3 h-3 mr-1" />
                Dublado
              </Badge>
            )}
          </div>
          
          <h3 className="text-white font-semibold text-sm md:text-base line-clamp-2">
            {movie.title}
          </h3>
          
          <div className="flex items-center gap-3 mt-2 text-xs text-gray-300">
            <span className="flex items-center gap-1">
              <Star className={`w-3 h-3 ${getRatingColor(movie.vote_average)}`} fill="currentColor" />
              <span className={getRatingColor(movie.vote_average)}>{movie.vote_average.toFixed(1)}</span>
            </span>
            <span>{movie.release_date.slice(0, 4)}</span>
            <span className="flex items-center gap-1">
              <Globe className="w-3 h-3" />
              {movie.original_language.toUpperCase()}
            </span>
          </div>

          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="w-14 h-14 rounded-full bg-primary/90 flex items-center justify-center glow-button transform scale-0 group-hover:scale-100 transition-transform duration-300">
              <Play className="w-6 h-6 text-white ml-1" fill="white" />
            </div>
          </div>
        </div>

        {/* Always visible info */}
        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/90 to-transparent rounded-b-xl group-hover:opacity-0 transition-opacity duration-300">
          <h3 className="text-white font-medium text-sm line-clamp-1">
            {movie.title}
          </h3>
          <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <Star className={`w-3 h-3 ${getRatingColor(movie.vote_average)}`} fill="currentColor" />
              {movie.vote_average.toFixed(1)}
            </span>
            <span>{movie.release_date.slice(0, 4)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
};
