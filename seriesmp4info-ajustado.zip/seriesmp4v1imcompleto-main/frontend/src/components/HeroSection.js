import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Info, Star, Clock, Mic2 } from 'lucide-react';

export const HeroSection = () => {
  const [featuredMovies, setFeaturedMovies] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const data = await api.getFeaturedMovies();
        setFeaturedMovies(data);
      } catch (error) {
        console.error('Error fetching featured movies:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchFeatured();
  }, []);

  useEffect(() => {
    if (featuredMovies.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredMovies.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [featuredMovies.length]);

  if (loading || featuredMovies.length === 0) {
    return (
      <div className="relative h-[70vh] md:h-[80vh] w-full bg-surface animate-pulse" data-testid="hero-loading">
        <div className="absolute bottom-0 left-0 right-0 h-1/2 hero-gradient" />
      </div>
    );
  }

  const movie = featuredMovies[currentIndex];

  const getRatingColor = (rating) => {
    if (rating >= 7.5) return 'text-emerald-400';
    if (rating >= 6) return 'text-amber-400';
    return 'text-red-400';
  };

  return (
    <section className="relative h-[70vh] md:h-[80vh] w-full overflow-hidden" data-testid="hero-section">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
        style={{ backgroundImage: `url(${movie.backdrop_path || movie.poster_path || '/placeholder-poster.svg'})` }}
      >
        <div className="absolute inset-0 bg-black/60" />
        <div className="absolute bottom-0 left-0 right-0 h-2/3 hero-gradient" />
      </div>

      {/* Content */}
      <div className="relative h-full container mx-auto px-4 md:px-6 lg:px-8 flex items-end pb-16 md:pb-24">
        <div className="max-w-2xl animate-slide-up">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            {movie.genres.slice(0, 3).map((genre, i) => (
              <Badge key={i} className="bg-primary/20 text-primary border-primary/30 text-xs uppercase tracking-wider backdrop-blur-sm">
                {genre}
              </Badge>
            ))}
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tighter text-white mb-4 font-heading">
            {movie.title}
          </h1>

          <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-gray-300">
            <span className={`flex items-center gap-1 font-semibold ${getRatingColor(movie.vote_average)}`}>
              <Star className="w-4 h-4" fill="currentColor" />
              {movie.vote_average.toFixed(1)}
            </span>
            <span>{movie.release_date.slice(0, 4)}</span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {Math.floor(movie.runtime / 60)}h {movie.runtime % 60}min
            </span>
            {movie.has_dubbing && (
              <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs backdrop-blur-sm">
                <Mic2 className="w-3 h-3 mr-1" />
                Dublado em PT
              </Badge>
            )}
          </div>

          <p className="text-gray-300 text-sm md:text-base line-clamp-3 mb-6 leading-relaxed">
            {movie.overview}
          </p>

          <div className="flex flex-wrap gap-3">
            <Link to={`/movie/${movie.id}`}>
              <Button 
                size="lg" 
                className="rounded-full px-8 bg-primary hover:bg-primary/80 text-white glow-button"
                data-testid="hero-details-btn"
              >
                <Info className="w-5 h-5 mr-2" />
                Ver Detalhes
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Indicators */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex gap-2">
        {featuredMovies.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`h-2 rounded-full transition-all duration-300 ${
              i === currentIndex ? 'w-8 bg-primary glow-dot' : 'w-2 bg-white/50 hover:bg-white/70'
            }`}
            data-testid={`hero-indicator-${i}`}
          />
        ))}
      </div>
    </section>
  );
};
