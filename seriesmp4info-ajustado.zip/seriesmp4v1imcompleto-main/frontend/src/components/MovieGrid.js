import { MovieCard } from './MovieCard';
import { Loader2 } from 'lucide-react';

export const MovieGrid = ({ movies, loading }) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-20" data-testid="movie-grid-loading">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (movies.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center" data-testid="movie-grid-empty">
        <div className="w-20 h-20 rounded-full bg-muted/50 flex items-center justify-center mb-4">
          <span className="text-4xl">🎬</span>
        </div>
        <h3 className="text-xl font-semibold mb-2">Nenhum filme encontrado</h3>
        <p className="text-muted-foreground">Tente ajustar os filtros de busca</p>
      </div>
    );
  }

  return (
    <div 
      className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6"
      data-testid="movie-grid"
    >
      {movies.map((movie, index) => (
        <MovieCard key={movie.id} movie={movie} index={index} />
      ))}
    </div>
  );
};
